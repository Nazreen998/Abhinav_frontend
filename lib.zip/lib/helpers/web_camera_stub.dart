class WebCameraHelper {
  static Future<bool> hasWebCamera() async => false;

  static Future<void> pickFromCamera(void Function(String) _) async {}
}
