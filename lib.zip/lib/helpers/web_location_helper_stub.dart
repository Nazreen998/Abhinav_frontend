import 'package:flutter/material.dart';

class WebLocationHelper {
  static Future<bool> isLocationBlocked() async => false;
  static void openLocationSettings() {}
  static void showLocationBlockedDialog(BuildContext context) {}
}
